package com.ahadu.game;

public class taker {
    String num,number,order;

    public taker(String num, String number, String order) {
        this.num = num;
        this.number = number;
        this.order = order;
    }

    public String getNum() {
        return num;
    }

    public String getNumber() {
        return number;
    }

    public String getOrder() {
        return order;
    }
}
